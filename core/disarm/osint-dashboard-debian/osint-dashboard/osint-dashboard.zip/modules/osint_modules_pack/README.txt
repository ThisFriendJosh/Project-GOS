Drop these .py files into your project's `modules/` folder.
Each file exposes a `module` instance compatible with the dashboard.
If you don't want paid-key modules, you can ignore `otx_pulses.py` and `shodan_counts.py`.
